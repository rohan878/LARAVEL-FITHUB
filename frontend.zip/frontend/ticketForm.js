document.getElementById('ticketForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const subject = document.getElementById('subject').value;
    const description = document.getElementById('description').value;

    fetch('http://localhost:8000/api/create-ticket', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ subject, description })
    })
    .then(response => response.json().then(data => ({ status: response.status, body: data })))
    .then(res => {
        if (res.status === 201) {
            document.getElementById('responseMessage').innerText = '✅ Ticket submitted successfully!';
        } else {
            // Show full error details from Laravel
            document.getElementById('responseMessage').innerText =
              '⚠️ Error (' + res.status + '): ' + JSON.stringify(res.body);
        }
    })
    .catch(error => {
        document.getElementById('responseMessage').innerText = '❌ Network error: ' + error;
    });
});
