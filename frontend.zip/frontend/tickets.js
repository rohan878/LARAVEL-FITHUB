fetch('http://localhost:8000/api/tickets')
.then(response => response.json())
.then(data => {
  const table = document.getElementById('ticketsTable');

  if (data.status === 'success') {
    data.tickets.forEach(ticket => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${ticket.id}</td>
        <td>${ticket.subject}</td>
        <td>${ticket.description}</td>
        <td>${ticket.status}</td>
      `;
      table.appendChild(row);
    });
  } else {
    document.getElementById('loadMessage').innerText = '⚠️ Error loading tickets: ' + data.message;
  }
})
.catch(error => {
  document.getElementById('loadMessage').innerText = '❌ Could not load tickets.';
  console.error(error);
});
